#include "Battery.h"

Battery::Battery(double v, double c, double initial)
    : voltage(v), capacity(c), charge(initial)
{
    if (charge < 0) charge = 0;
    if (charge > capacity) charge = capacity;
}

void Battery::use(double hours) {
    charge -= hours * DISCHARGE_RATE;
    if (charge < 0) charge = 0;
}

void Battery::recharge(double hours) {
    charge += hours * RECHARGE_RATE;
    if (charge > capacity) charge = capacity;
}

double Battery::getVoltage() const { return voltage; }
double Battery::getCapacity() const { return capacity; }
double Battery::getCharge() const { return charge; }

double Battery::getPercent() const {
    if (capacity == 0) return 0.0;
    return (charge / capacity) * 100.0;
}
