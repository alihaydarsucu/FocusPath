#ifndef BATTERY_H
#define BATTERY_H

#include <algorithm>

/**
 * @class Battery
 * @brief Represents a single battery cell with voltage, capacity, and charge.
 */
class Battery {
protected:
    /**
     * @brief Fixed discharge rate in mAh/hour.
     */
    static constexpr double DISCHARGE_RATE = 100.0;

    /**
     * @brief Fixed recharge rate in mAh/hour.
     */
    static constexpr double RECHARGE_RATE = 150.0;

private:
    /**
     * @brief Voltage of the cell (Volts).
     */
    double voltage;

    /**
     * @brief Maximum capacity of the cell (mAh).
     */
    double capacity;

    /**
     * @brief Current charge of the cell (mAh).
     */
    double charge;

public:
    /**
     * @brief Constructs a Battery object.
     * @param v Voltage in volts.
     * @param c Capacity in mAh.
     * @param initial Initial charge in mAh.
     */
    Battery(double v, double c, double initial);

    /**
     * @brief Discharges the battery.
     * @param hours Hours of usage.
     */
    virtual void use(double hours);

    /**
     * @brief Recharges the battery.
     * @param hours Hours spent charging.
     */
    virtual void recharge(double hours);

    /**
     * @brief Gets the voltage of the battery.
     * @return Voltage in volts.
     */
    virtual double getVoltage() const;

    /**
     * @brief Gets the battery capacity.
     * @return Capacity in mAh.
     */
    virtual double getCapacity() const;

    /**
     * @brief Gets the current charge value.
     * @return Charge in mAh.
     */
    virtual double getCharge() const;

    /**
     * @brief Gets the charge percentage.
     * @return Charge level in percent (0–100).
     */
    virtual double getPercent() const;

    /**
     * @brief Virtual destructor.
     */
    virtual ~Battery() {}
};

#endif
