#include "BatteryPack.h"
#include <algorithm>

BatteryPack::BatteryPack(ConnectionType t)
    : Battery(0, 0, 0), type(t)
{}

void BatteryPack::add(Battery* b) {
    if (b) cells.push_back(b);
}

void BatteryPack::use(double hours) {
    for (Battery* b : cells)
        b->use(hours);
}

void BatteryPack::recharge(double hours) {
    for (Battery* b : cells)
        b->recharge(hours);
}

double BatteryPack::getVoltage() const {
    if (cells.empty()) return 0;

    if (type == SERIES) {
        double total = 0;
        for (Battery* b : cells) total += b->getVoltage();
        return total;
    }
    return cells[0]->getVoltage(); // PARALLEL
}

double BatteryPack::getCapacity() const {
    if (cells.empty()) return 0;

    if (type == SERIES) {
        double minCap = cells[0]->getCapacity();
        for (Battery* b : cells)
            minCap = std::min(minCap, b->getCapacity());
        return minCap;
    }

    double sum = 0;
    for (Battery* b : cells) sum += b->getCapacity();
    return sum;
}

double BatteryPack::getCharge() const {
    if (cells.empty()) return 0;

    if (type == SERIES) {
        double minCh = cells[0]->getCharge();
        for (Battery* b : cells)
            minCh = std::min(minCh, b->getCharge());
        return minCh;
    }

    double sum = 0;
    for (Battery* b : cells) sum += b->getCharge();
    return sum;
}
