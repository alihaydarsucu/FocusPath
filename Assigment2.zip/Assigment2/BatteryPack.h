#ifndef BATTERYPACK_H
#define BATTERYPACK_H

#include "Battery.h"
#include <vector>

/**
 * @class BatteryPack
 * @brief Represents a group of battery cells connected in series or parallel.
 */
class BatteryPack : public Battery {
public:
    /**
     * @brief Type of electrical connection between cells.
     */
    enum ConnectionType { SERIES, PARALLEL };

private:
    /**
     * @brief Connection type of the battery pack.
     */
    ConnectionType type;

    /**
     * @brief List of battery cells inside the pack.
     */
    std::vector<Battery*> cells;

public:
    /**
     * @brief Constructs a BatteryPack.
     * Parent Battery is initialized with dummy values (0,0,0).
     * @param t Connection type (SERIES or PARALLEL).
     */
    BatteryPack(ConnectionType t);

    /**
     * @brief Adds a battery cell into the pack.
     * @param b Pointer to a Battery object.
     */
    void add(Battery* b);

    /**
     * @brief Discharges all batteries in the pack.
     * @param hours Hours of usage.
     */
    void use(double hours) override;

    /**
     * @brief Recharges all batteries in the pack.
     * @param hours Hours spent charging.
     */
    void recharge(double hours) override;

    /**
     * @brief Computes total voltage depending on connection type.
     * @return Voltage in volts.
     */
    double getVoltage() const override;

    /**
     * @brief Computes capacity depending on connection type.
     * @return Capacity in mAh.
     */
    double getCapacity() const override;

    /**
     * @brief Computes charge depending on connection type.
     * @return Charge in mAh.
     */
    double getCharge() const override;
};

#endif
