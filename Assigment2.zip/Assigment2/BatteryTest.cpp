#include <iostream>
#include "Battery.h"
#include "BatteryPack.h"

/*
 Comprehensive test file (clean, well-formatted).
 This file runs:
  - single battery checks
  - sample test from PDF (3 cells in series)
  - series pack demonstration
  - parallel pack demonstration

 Expected sample output (from PDF) for the specific sample:
 Initial:
 Voltage: 11.1
 Capacity: 2000
 Charge: 1500

 After 1 hour use:
 Charge: 1400

 After 1 hour recharge:
 Charge: 1550
*/

int main() {
    std::cout << "=== Single Battery Demo ===\n";
    Battery b1(3.7, 2000, 1500);
    std::cout << "Voltage: " << b1.getVoltage() << "\n";
    std::cout << "Capacity: " << b1.getCapacity() << "\n";
    std::cout << "Charge: " << b1.getCharge() << "\n";
    std::cout << "Percent: " << b1.getPercent() << "%\n\n";

    b1.use(1.0);
    std::cout << "After 1 hour use, charge: " << b1.getCharge() << "\n";
    b1.recharge(1.0);
    std::cout << "After 1 hour recharge, charge: " << b1.getCharge() << "\n\n";

    std::cout << "=== PDF Sample (3 cells SERIES) ===\n";
    Battery s1(3.7, 2000, 1500);
    Battery s2(3.7, 2000, 1800);
    Battery s3(3.7, 2000, 2000);

    BatteryPack packSeries(BatteryPack::SERIES);
    packSeries.add(&s1);
    packSeries.add(&s2);
    packSeries.add(&s3);

    std::cout << "Initial:\n";
    std::cout << "Voltage: " << packSeries.getVoltage() << "\n";
    std::cout << "Capacity: " << packSeries.getCapacity() << "\n";
    std::cout << "Charge: " << packSeries.getCharge() << "\n\n";

    packSeries.use(1.0);
    std::cout << "After 1 hour use:\n";
    std::cout << "Charge: " << packSeries.getCharge() << "\n\n";

    packSeries.recharge(1.0);
    std::cout << "After 1 hour recharge:\n";
    std::cout << "Charge: " << packSeries.getCharge() << "\n\n";

    std::cout << "=== PARALLEL Demo ===\n";
    Battery p1(3.7, 1000, 900);
    Battery p2(3.7, 1500, 1200);
    BatteryPack packParallel(BatteryPack::PARALLEL);
    packParallel.add(&p1);
    packParallel.add(&p2);

    std::cout << "Voltage: " << packParallel.getVoltage() << "\n";
    std::cout << "Capacity: " << packParallel.getCapacity() << "\n";
    std::cout << "Charge: " << packParallel.getCharge() << "\n\n";

    packParallel.use(1.0);
    std::cout << "After 1h use (PARALLEL), Charge: " << packParallel.getCharge() << "\n";
    packParallel.recharge(1.0);
    std::cout << "After 1h recharge (PARALLEL), Charge: " << packParallel.getCharge() << "\n\n";

    return 0;
}
