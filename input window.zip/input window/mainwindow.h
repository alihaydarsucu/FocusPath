#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QStackedWidget>
#include "clickablelabel.h"

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();



private:
    QStackedWidget *stackedWidget = nullptr;

    ClickableLabel *dashboard = nullptr;
    ClickableLabel *workflowSetup = nullptr;
    ClickableLabel *history = nullptr;
    ClickableLabel *templates = nullptr;

    ClickableLabel *current = nullptr;


    QStackedWidget *stack;

};

#endif // MAINWINDOW_H
