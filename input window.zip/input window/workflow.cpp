#include "Workflow.h"
#include <ctime>
#include <iostream>

void Workflow::setCurrentDateTime()
{
    createdAt = std::chrono::system_clock::now();

    std::time_t time = std::chrono::system_clock::to_time_t(createdAt);
    std::tm* localTime = std::localtime(&time);

    char buffer[30];
    std::strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", localTime);

    date = buffer;


    if (name.empty()) {
        name = date;
    }
}


Workflow::Workflow(long duration, bool isFavorite)
    : name(""), duration(duration), isFavorite(isFavorite)
{
    setCurrentDateTime();
}


Workflow::Workflow(std::string name, long duration, bool isFavorite)
    : name(name), duration(duration), isFavorite(isFavorite)
{
    setCurrentDateTime();
}

void Workflow::addApps(std::string appName)
{
    apps.push_back(appName);
}

std::string Workflow::getDate() const
{
    return date;
}

std::string Workflow::getName() const
{
    return name;
}

long Workflow::getDuration() const
{
    return duration;
}

void Workflow::print() const
{
    std::cout << name << std::endl;
    std::cout << duration << std::endl;
    std::cout << date << std::endl;
    std::cout << isFavorite << std::endl;
}
